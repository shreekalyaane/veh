<!-- footer starts here -->
<div class="footer">
	
		<p>			&copy; 2012-2013 E-Workshop<strong></strong> &nbsp;&nbsp;	 
	    <a href="emplogin.php">Employee login</a>	</p>
		
</div>	
	
</body>
</html>
